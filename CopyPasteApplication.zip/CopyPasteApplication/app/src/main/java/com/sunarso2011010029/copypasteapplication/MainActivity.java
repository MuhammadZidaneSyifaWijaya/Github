package com.sunarso2011010029.copypasteapplication;

import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.nio.charset.Charset;
import java.util.List;
import com.sunarso2011010029.copypasteapplication.R;

public class MainActivity extends AppCompatActivity
{
    EditText usrCopyText;
    Button btnCopy;
    Button btnPaste;
    private ClipboardManager myClipboard;
    private ClipData myClip;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myClipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
    }

    public void OnClickCopy(View view)
    {
        usrCopyText = (EditText)(findViewById(R.id.editUserText));
        String copyText = usrCopyText.getText().toString();
        // encode the text to change the cache
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            myClip = ClipData.newPlainText("", copyText);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            myClipboard.setPrimaryClip(myClip);
        }
        Toast.makeText(getApplicationContext(), "Text Copied",
                Toast.LENGTH_SHORT).show();
    }

    public void OnClickPaste(View view)
    {
        ClipData abc = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB) {
            abc = myClipboard.getPrimaryClip();
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB) {
            ClipData.Item item = abc.getItemAt(0);
            String text = item.getText().toString();
            Toast.makeText(getApplicationContext(), "Text Pasted: " + text,
                    Toast.LENGTH_SHORT).show();
        }
    }
}