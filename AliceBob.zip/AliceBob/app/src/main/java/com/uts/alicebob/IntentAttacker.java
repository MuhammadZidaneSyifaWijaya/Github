package com.uts.alicebob;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class IntentAttacker extends AppCompatActivity {
    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.intent_attacker);
    }
}
