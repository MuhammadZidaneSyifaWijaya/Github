package com.uts.alicebob;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Alice extends AppCompatActivity {
    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.aclie);

        Intent intent = getIntent();

        TextView textView = (TextView) findViewById(R.id.pesan_alice);
        textView.setText(intent.getStringExtra("msg"));
    }
}
