package com.uts.alicebob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText pesan = (EditText) findViewById(R.id.id_pesan);
        Button send_button = (Button) findViewById(R.id.id_button);

        send_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("message");
                intent.setComponent(new ComponentName("com.uts.intruder",
                        "com.uts.intruder.MyBroadcastReceiver"));
                intent.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                intent.putExtra("msg", pesan.getText().toString());

                getApplicationContext().sendBroadcast(intent);

                Intent intent1 = new Intent(MainActivity.this,
                        Alice.class);
                intent1.putExtra("msg", pesan.getText().toString());
                startActivity(intent1);
            }
        });
    }
}