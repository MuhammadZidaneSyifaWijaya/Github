package com.example.inputvalidation;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
public class DatabaseHelper extends SQLiteOpenHelper {
    public static int num = 0;
    public static final String TB_NAME="usertable";
    public static final String ID="_id";
    public static final String USERNAME="username";
    public static final String PASSWORD="password";
    public static final int del = 2;
    public DatabaseHelper(Context context, String name,
                          SQLiteDatabase.CursorFactory factory,
                          int version) {
        super(context, name, factory, version);
// TODO Auto-generated constructor stub
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS "+TB_NAME+" ("+ID+" INTEGER PRIMARY KEY,"+USERNAME+" VARCHAR,"+PASSWORD+" VARCHAR )");
// create the java statement
        String count = "SELECT count(*) FROM usertable";
        Cursor mcursor = db.rawQuery(count, null);
        mcursor.moveToFirst();
        int icount = mcursor.getInt(0);
        if(icount==0) {
// execute the query, and get a java resultset
            db.execSQL("INSERT INTO " + TB_NAME + "(" + USERNAME + "," +PASSWORD + ") VALUES" + "('zidan','22')");
            db.execSQL("INSERT INTO " + TB_NAME + "(" + USERNAME + "," +PASSWORD + ") VALUES" + "('syifa','110')");
            db.execSQL("INSERT INTO " + TB_NAME + "(" + USERNAME + "," +PASSWORD + ") VALUES" + "('wijaya','06')");
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int
            newVersion) {
        Log.w(DatabaseHelper.class.getName(),
                "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
//db.execSQL("DROP TABLE IF EXISTS " + TABLE_COMMENTS);
                onCreate(db);
    }
    @Override
    public void onOpen(SQLiteDatabase db) {
// TODO Auto-generated method stub
        super.onOpen(db);
    }
}


