package com.mobile_security.sql_validation;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class MainActivity extends AppCompatActivity {
    //Button showButton;
    EditText input;
    TextView showInput;
    DatabaseHelper dbhelper;
    SQLiteDatabase db;
    public static final String TB_NAME="usertable";
    //public static String result = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//showButton = (Button) findViewById(R.id.button_1);
        input = (EditText) findViewById(R.id.editText);
        showInput = (TextView) findViewById(R.id.textView2);
        dbhelper=new DatabaseHelper(this, TB_NAME, null, 1);
        db=dbhelper.getWritableDatabase();
    }
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_1:
                showResult(input.getText().toString());
                break;
            case R.id.button_2:
                if (!isValidSearch(input.getText().toString())) {
                    input.setError("Invalid Search");
                }
                else {
                    showResult(input.getText().toString());
                }
                break;
            case R.id.button_3:
                Cursor cursor;
                String m_argv[] = {input.getText().toString()};
                cursor=db.rawQuery("SELECT * FROM usertable WHERE _id= ? ",m_argv );
                cursor.moveToFirst();
                String result = null;
                while (!cursor.isAfterLast()) {
                    result += "id:" + cursor.getInt(0)
                            + "\r\n" + "user:" + cursor.getString(1) + "\r\n" + "pass:" +
                            cursor.getString(2) + "\r\n";
                    cursor.moveToNext();
                }
                showInput.setText(result);
                cursor.close();
                break;
            case R.id.button_4:
                showResult("");
                break;
        }
    }
    public void showResult(String info){
        if(info == null || info.length() <= 0)
            showInput.setText("Please input:");
        else{
            Cursor cursor;
            cursor = db.rawQuery("SELECT * FROM usertable WHERE _id='" + info + "'", null);
            cursor.moveToFirst();
            String result = null;
            while (!cursor.isAfterLast()) {
                result += "id:" + cursor.getInt(0)
                        + "\r\n" + "user:" + cursor.getString(1) + "\r\n" + "pass:" +
                        cursor.getString(2) + "\r\n";
                cursor.moveToNext();
            }
            showInput.setText(result);
            cursor.close();
        }
    }
    private boolean isValidSearch(String name) {
//String NAME_PATTERN = "^\\W$";
        String NAME_PATTERN = "^^[0-9]*$";
        Pattern pattern = Pattern.compile(NAME_PATTERN);
        Matcher matcher = pattern.matcher(name);
//System.out.println(matcher.matches());
        return matcher.matches();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
// Inflate the menu; this adds items to the action bar if itis present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
// Handle action bar item clicks here. The action bar will
// automatically handle clicks on the Home/Up button, solong
// as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
//noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
