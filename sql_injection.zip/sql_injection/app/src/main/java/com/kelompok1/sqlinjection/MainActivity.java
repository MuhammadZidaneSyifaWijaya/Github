package com.kelompok1.sqlinjection;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            sqLiteDatabase = openOrCreateDatabase("sqli", 0, null);
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS sqlarfesu;");
            sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS sqlarfesu (user VARCHAR, pwd VARCHAR, npm VARCHAR);");
            sqLiteDatabase.execSQL("INSERT INTO sqlarfesu (user, pwd, npm) VALUES ('febri', 'febri666', '28')");
            sqLiteDatabase.execSQL("INSERT INTO sqlarfesu (user, pwd, npm) VALUES ('arif', 'arif13', '35')");
            sqLiteDatabase.execSQL("INSERT INTO sqlarfesu (user, pwd, npm) VALUES ('sunarso', 'xXsunarsoXx', '29')");
        }catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }

        findViewById(R.id.confirm_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
            }
        });
    }

    protected void search() {
        EditText inputText = (EditText) findViewById(R.id.inputText);

        try {
            Cursor localCursor = sqLiteDatabase.rawQuery("SELECT * FROM sqlarfesu WHERE user = '" + inputText.getText().toString() + "'", null);
            if ((localCursor != null) && (localCursor.getCount() > 0)) {
                localCursor.moveToFirst();
                Toast.makeText(getApplicationContext(), localCursor.getString(0), Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }
}