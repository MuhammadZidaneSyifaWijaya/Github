package com.intent.usersqlinjection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText username = (EditText) findViewById(R.id.et_username);
        EditText password = (EditText) findViewById(R.id.et_password);
        EditText url = (EditText) findViewById(R.id.et_url);

        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((url.getText().toString() != null) && (!(url.getText().toString().equals("")))) {
                    getDataAndLogin(url.getText().toString(), username.getText().toString());
                }
            }
        });
    }

    protected void getDataAndLogin(String url, String user) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url + "?username=" + user,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                if (user.equals(jsonObject.getString("username").toLowerCase())) {
                                    Toast.makeText(MainActivity.this, "login berhasil", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(MainActivity.this, HasilActivity.class);
                                    intent.putExtra("username", jsonObject.getString("username"));
                                    intent.putExtra("password", jsonObject.getString("password"));
                                    intent.putExtra("npm", jsonObject.getString("npm"));
                                    intent.putExtra("alamat", jsonObject.getString("alamat"));
                                    startActivity(intent);
                                    break;
                                }
                            }
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(stringRequest);
    }
}