package com.intent.usersqlinjection;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class HasilActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil);

        Intent intent = getIntent();

        TextView user = (TextView) findViewById(R.id.user);
        TextView pass = (TextView) findViewById(R.id.pass);
        TextView npm = (TextView) findViewById(R.id.npm);
        TextView alamat = (TextView) findViewById(R.id.alamat);

        user.setText(intent.getStringExtra("username"));
        pass.setText(intent.getStringExtra("password"));
        npm.setText(intent.getStringExtra("npm"));
        alamat.setText(intent.getStringExtra("alamat"));
    }
}
