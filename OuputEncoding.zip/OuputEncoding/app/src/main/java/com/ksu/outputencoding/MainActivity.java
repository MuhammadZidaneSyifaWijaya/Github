package com.ksu.outputencoding;

import android.os.Bundle;
import android.support.v4.app.*;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.text.TextUtils;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.ksu.outputencoding.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    TextView encoded;
    Button unsecure;
    Button secure;
    Button encodedResult;
    WebView webView;



    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView); encoded = (TextView) findViewById(R.id.textView2);
        unsecure = (Button) findViewById(R.id.button);
        secure = (Button) findViewById(R.id.button2);
        encodedResult = (Button) findViewById(R.id.button3);
        webView = (WebView) findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);

        String script = "Demostrating the consequences of the script:\n<script>alert(\"You have been attacked!\")</script>";
        String html = "<html><body>" + script + "</body></html>";
        textView.setText(script);

        unsecure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                webView.setWebChromeClient(new WebChromeClient());
                webView.setVisibility(View.VISIBLE);
                webView.loadUrl("file:///android_asset/unsecure.html");

                encoded.setText("");
            }
        });
                secure.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String secureHTML = "<html><head><title>Secure</title></head><body><h1> Hello "+TextUtils.htmlEncode("<script>alert(\"Muhammad Zidane Syifa Wijaya\")</script>")+"!</h1></body></html>";
                        webView.setWebChromeClient(new WebChromeClient());
                        webView.setVisibility(View.VISIBLE);
                        webView.loadDataWithBaseURL(null, secureHTML, "text/html", "utf-8", null);
                        encoded.setText("");
                    }
                });
                encodedResult.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        encodedResult.setText(TextUtils.htmlEncode("<script>alert(\"Muhammad Zidane Syifa Wijaya!Kamu Diserang\")</script>"));
                        webView.setVisibility(View.GONE);
                        webView.loadData("","text/html", null);

                    }
                });
    }
}